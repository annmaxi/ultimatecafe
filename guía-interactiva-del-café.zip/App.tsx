
import React from 'react';
import Header from './components/Header';
import Introduction from './components/Introduction';
import CurrentPrice from './components/CurrentPrice';
import History from './components/History';
import Varieties from './components/Varieties';
import Market from './components/Market';
import Processing from './components/Processing';
import Roasting from './components/Roasting';
import FlavorMap from './components/FlavorMap';
import Economy from './components/Economy';
import BaristaToolkit from './components/BaristaToolkit';
import Storytelling from './components/Storytelling';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <>
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <Introduction />
        <CurrentPrice />
        <History />
        <Varieties />
        <Market />
        <Processing />
        <Roasting />
        <FlavorMap />
        <Economy />
        <BaristaToolkit />
        <Storytelling />
      </main>
      <Footer />
    </>
  );
};

export default App;
