
import React, { useState, useEffect, useCallback } from 'react';

type CoffeeType = 'arabica' | 'robusta';

interface PriceData {
    title: string;
    currentPrice: number;
    lastUpdate: string;
    change: number;
}

const initialPriceData: Record<CoffeeType, PriceData> = {
    arabica: {
        title: 'Precio de Futuros del Café Arábica (USD/libra)',
        currentPrice: 289.60,
        lastUpdate: new Date().toLocaleString('es-ES'),
        change: 0.00
    },
    robusta: {
        title: 'Precio de Futuros del Café Robusta (USD/tonelada)',
        currentPrice: 3569.00,
        lastUpdate: new Date().toLocaleString('es-ES'),
        change: 0.00
    }
};

const formatPrice = (price: number) => price.toFixed(2).replace('.', ',');
const formatChange = (change: number) => {
    const sign = change >= 0 ? '+' : '';
    const className = change >= 0 ? 'text-green-600' : 'text-red-600';
    return <span className={className}>{sign}{formatPrice(change)}</span>;
};

const CurrentPrice: React.FC = () => {
    const [activeType, setActiveType] = useState<CoffeeType>('arabica');
    const [priceData, setPriceData] = useState<Record<CoffeeType, PriceData>>(initialPriceData);

    const simulatePriceChange = useCallback(() => {
        setPriceData(prevData => {
            const data = { ...prevData[activeType] };
            const oldPrice = data.currentPrice;
            const fluctuation = (Math.random() * 2 - 1) * (activeType === 'arabica' ? 0.50 : 15.00);
            let newPrice = oldPrice + fluctuation;

            if (activeType === 'arabica' && newPrice < 250) newPrice = 250 + Math.random() * 10;
            if (activeType === 'robusta' && newPrice < 3000) newPrice = 3000 + Math.random() * 50;

            newPrice = parseFloat(newPrice.toFixed(2));

            data.change = newPrice - oldPrice;
            data.currentPrice = newPrice;
            data.lastUpdate = new Date().toLocaleString('es-ES');
            
            return { ...prevData, [activeType]: data };
        });
    }, [activeType]);
    
    useEffect(() => {
        const intervalId = setInterval(simulatePriceChange, 15000);
        return () => clearInterval(intervalId);
    }, [simulatePriceChange]);

    const handleTypeChange = (type: CoffeeType) => {
        setActiveType(type);
    };

    const data = priceData[activeType];

    return (
        <section id="precio-actual" className="mb-20 bg-white rounded-xl shadow-lg p-8 max-w-3xl mx-auto border-4 border-[#D3756B]">
            <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-[#D3756B]">Precio Actual del Café (Simulado)</h3>
                <p className="text-md text-gray-600 max-w-2xl mx-auto mt-2">
                    Los precios mostrados a continuación son **simulados** y se actualizan automáticamente cada 15 segundos. Para datos en tiempo real y oficiales, por favor, consulta los enlaces a Investing.com.
                </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-8">
                <button
                    onClick={() => handleTypeChange('arabica')}
                    className={`px-4 py-2 rounded-full shadow font-semibold transition ${activeType === 'arabica' ? 'bg-[#D3756B] text-white' : 'bg-white'}`}
                >
                    Café Arábica
                </button>
                <button
                    onClick={() => handleTypeChange('robusta')}
                    className={`px-4 py-2 rounded-full shadow font-semibold transition ${activeType === 'robusta' ? 'bg-[#D3756B] text-white' : 'bg-white'}`}
                >
                    Café Robusta
                </button>
            </div>
            <div id="current-price-display" className="text-center">
                <h4 className="text-xl font-bold mb-2">{data.title}</h4>
                <p className="text-6xl font-black text-[#4E443F] mb-2">${formatPrice(data.currentPrice)}</p>
                <p className="text-lg text-gray-600 mb-4">Cambio: {formatChange(data.change)}</p>
                <p className="text-sm text-gray-500">Última actualización (simulada): {data.lastUpdate}</p>
            </div>
            <div className="text-center mt-6">
                <button
                    onClick={simulatePriceChange}
                    className="bg-[#F7D1BA] text-[#4E443F] px-6 py-3 rounded-full font-semibold shadow-md hover:bg-[#E8A39C] transition-colors duration-300"
                >
                    Actualizar Precio Ahora
                </button>
                <p className="text-sm text-gray-500 mt-4">
                    Para datos en tiempo real y oficiales, consulta:
                    <a href="https://es.investing.com/commodities/arabica-coffee-4-5" target="_blank" rel="noopener noreferrer" className="text-[#D3756B] hover:underline ml-1">Arábica en Investing.com</a> |
                    <a href="https://es.investing.com/commodities/london-coffee" target="_blank" rel="noopener noreferrer" className="text-[#D3756B] hover:underline ml-1">Robusta en Investing.com</a>
                </p>
            </div>
        </section>
    );
};

export default CurrentPrice;
