
import React from 'react';

const Introduction: React.FC = () => {
    return (
        <section id="intro" className="text-center my-12 md:my-16">
            <h2 className="text-4xl md:text-6xl font-black mb-4">El Arte y la Ciencia del Café de Especialidad</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Una exploración interactiva del viaje del café, desde las fincas globales hasta la taza. Descubre los datos, tendencias y técnicas que definen el café de alta calidad.
            </p>
        </section>
    );
};

export default Introduction;
