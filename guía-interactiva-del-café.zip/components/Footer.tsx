
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-[#4E443F] text-white/70 text-center py-6 mt-16">
            <p>Aplicación Interactiva del Café de Especialidad</p>
            <p className="text-sm mt-1">Creada a partir del "Ebook de Café Especialidad Profesional".</p>
        </footer>
    );
};

export default Footer;
