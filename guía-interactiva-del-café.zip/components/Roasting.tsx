
import React from 'react';

const Roasting: React.FC = () => {
    return (
        <section id="tueste" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">El Alma del Café: El Arte del Tueste</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    El tueste es la transformación mágica que libera más de 850 sustancias aromáticas. Las reacciones de Maillard y Caramelización, junto con las etapas de secado y "cracks", definen el perfil final.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white rounded-xl shadow-lg p-6">
                <div>
                    <h4 className="text-xl font-bold mb-3">Reacciones Clave: Maillard y Caramelización</h4>
                    <p className="text-gray-600 mb-4">
                        La <strong>Reacción de Maillard</strong> (desde 120°C) entre azúcares y aminoácidos es responsable de la mayoría de los nuevos aromas, sabores y el color marrón del café. La <strong>Caramelización</strong> (desde 160°C) descompone los azúcares, creando notas dulces y caramelizadas, especialmente en tuestes más oscuros.
                    </p>
                    <h4 className="text-xl font-bold mb-3 mt-6">Etapas del Tueste</h4>
                    <ul className="list-disc list-inside text-gray-600 space-y-2">
                        <li><strong>Secado:</strong> El grano pierde humedad, cambiando de verde a amarillo.</li>
                        <li><strong>Primer Crack:</strong> Sonido de "pop" al expandirse el grano, marcando el inicio del desarrollo del sabor.</li>
                        <li><strong>Desarrollo:</strong> Fase crucial donde se forman la mayoría de los compuestos de sabor.</li>
                        <li><strong>Segundo Crack:</strong> Sonido más suave en tuestes oscuros, indicando mayor degradación y liberación de aceites.</li>
                    </ul>
                </div>
                <div className="bg-[#F7D1BA] flex items-center justify-center text-[#4E443F] font-bold text-center rounded-lg h-64 md:h-96">
                   <img src="https://picsum.photos/seed/coffeeroaster/600/400" alt="Tostador de café" className="w-full h-full object-cover rounded-md" />
                </div>
            </div>
        </section>
    );
};

export default Roasting;
