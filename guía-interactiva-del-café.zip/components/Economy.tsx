
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { PRICE_FORECAST_DATA, COLORS } from '../constants';

const Economy: React.FC = () => {
    return (
        <section id="economia" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">La Volatilidad de los Precios</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    El precio del café es un complejo baile de factores globales. El clima, la logística y la especulación financiera crean un mercado impredecible, con previsiones a menudo divergentes para los próximos años.
                </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-stretch">
                <div className="bg-white rounded-xl shadow-lg p-6 lg:col-span-3">
                    <h4 className="text-xl font-bold text-center mb-1">Previsiones del Precio del Arábica (2025-26)</h4>
                    <p className="text-center text-sm text-gray-500 mb-4">
                        Los analistas muestran un panorama mixto, reflejando la incertidumbre sobre la oferta y la demanda futuras.
                    </p>
                    <div className="w-full h-[350px] md:h-[400px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={PRICE_FORECAST_DATA} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" stroke={COLORS.text} />
                                <YAxis label={{ value: 'USD/libra', angle: -90, position: 'insideLeft', fill: COLORS.text }} stroke={COLORS.text} />
                                <Tooltip 
                                    contentStyle={{
                                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
                                      border: '1px solid #cccccc',
                                      borderRadius: '0.5rem',
                                    }}
                                />
                                <Legend wrapperStyle={{ color: COLORS.text }} />
                                <Line type="monotone" dataKey="Banco Mundial (Alcista)" stroke={COLORS.primary} activeDot={{ r: 8 }} />
                                <Line type="monotone" dataKey="Reuters (Bajista)" stroke={COLORS.secondary} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                <div className="bg-white rounded-xl shadow-lg p-8 lg:col-span-2 flex flex-col justify-center">
                    <h4 className="text-xl font-bold mb-6">Factores Clave en Juego</h4>
                    <ul className="space-y-6">
                        <li className="flex items-start">
                            <span className="text-3xl mr-4">🌡️</span>
                            <div>
                                <h5 className="font-bold">Clima Extremo</h5>
                                <p className="text-sm text-gray-600">Sequías y heladas en Brasil o Vietnam pueden reducir drásticamente la oferta global.</p>
                            </div>
                        </li>
                        <li className="flex items-start">
                            <span className="text-3xl mr-4">🚚</span>
                            <div>
                                <h5 className="font-bold">Logística y Geopolítica</h5>
                                <p className="text-sm text-gray-600">Costes de transporte y conflictos en rutas marítimas añaden presión a los precios.</p>
                            </div>
                        </li>
                        <li className="flex items-start">
                            <span className="text-3xl mr-4">📈</span>
                            <div>
                                <h5 className="font-bold">Demanda Creciente</h5>
                                <p className="text-sm text-gray-600">Mercados como China duplican su consumo, ejerciendo presión sobre la oferta disponible.</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
    );
};

export default Economy;
