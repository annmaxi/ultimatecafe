
import React from 'react';

const navLinks = [
    { href: "#mercado", label: "Mercado" },
    { href: "#precio-actual", label: "Precio Actual" },
    { href: "#historia", label: "Historia" },
    { href: "#variedades", label: "Variedades" },
    { href: "#proceso", label: "Proceso" },
    { href: "#tueste", label: "Tueste" },
    { href: "#sabor", label: "Sabor Regional" },
    { href: "#economia", label: "Economía" },
    { href: "#barista", label: "Barista" },
    { href: "#storytelling", label: "Venta" }
];

const NavLink: React.FC<{ href: string; label: string }> = ({ href, label }) => (
    <a href={href} className="text-gray-600 border-b-2 border-transparent pb-1 transition-colors duration-300 hover:text-[#D3756B] hover:border-[#D3756B]">
        {label}
    </a>
);

const Header: React.FC = () => {
    return (
        <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-50">
            <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
                <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#D3756B] to-[#4E443F]">
                    Guía Interactiva del Café
                </h1>
                <div className="hidden lg:flex flex-wrap items-center justify-center space-x-4">
                   {navLinks.map(link => <NavLink key={link.href} {...link} />)}
                </div>
            </nav>
        </header>
    );
};

export default Header;
