
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { TOP_PRODUCERS_DATA } from '../constants';

const Market: React.FC = () => {
    return (
        <section id="mercado" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">El Mercado Global</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    El café es una de las materias primas más comercializadas del mundo. Un puñado de países domina la producción, mientras que el consumo global sigue alcanzando nuevas cotas, impulsado por mercados emergentes.
                </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
                <div className="bg-white rounded-xl shadow-lg p-6 lg:col-span-2">
                    <h4 className="text-xl font-bold text-center mb-1">Top 10 Países Productores (2024)</h4>
                    <p className="text-center text-sm text-gray-500 mb-4">La producción se concentra fuertemente en Brasil y Vietnam, cuyas cosechas tienen un impacto masivo en la oferta y los precios a nivel mundial.</p>
                    <div className="w-full h-[450px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={TOP_PRODUCERS_DATA} layout="vertical" margin={{ top: 5, right: 20, left: 50, bottom: 5 }}>
                                <XAxis type="number" stroke="#4E443F" />
                                <YAxis type="category" dataKey="name" width={80} stroke="#4E443F" interval={0} />
                                <Tooltip
                                  cursor={{fill: 'rgba(247, 209, 186, 0.3)'}}
                                  contentStyle={{
                                    backgroundColor: '#ffffff',
                                    border: '1px solid #cccccc',
                                    borderRadius: '0.5rem',
                                  }}
                                />
                                <Bar dataKey="value" background={{ fill: '#f1f5f9' }}>
                                    {TOP_PRODUCERS_DATA.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.fill} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                <div className="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center justify-center text-center h-full">
                    <h4 className="text-xl font-bold mb-4">Consumo Global Proyectado</h4>
                    <p className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-br from-[#D3756B] to-[#E8A39C]">
                        169.4M
                    </p>
                    <p className="text-xl text-gray-600">de sacos de 60kg</p>
                    <p className="mt-4 text-sm text-gray-500">
                        La demanda para la temporada 2025/26 marca un récord, mostrando la resistencia y popularidad creciente del café a pesar de la volatilidad de precios.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default Market;
