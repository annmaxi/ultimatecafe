
import React from 'react';

interface ProcessNodeProps {
    icon: string;
    title: string;
    description: string;
}

const ProcessNode: React.FC<ProcessNodeProps> = ({ icon, title, description }) => (
    <div className="bg-white p-6 rounded-lg shadow-lg text-center transition-all duration-300 ease-in-out border-2 border-transparent hover:transform hover:-translate-y-1 hover:shadow-xl hover:border-[#D3756B]">
        <span className="text-4xl">{icon}</span>
        <h4 className="font-bold text-lg mt-2">{title}</h4>
        <p className="text-sm text-gray-600 mt-2">{description}</p>
    </div>
);

const Processing: React.FC = () => {
    return (
        <section id="proceso" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">La Alquimia del Procesamiento</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    Tras la cosecha, el método de beneficiado transforma la cereza de café y es decisivo para el perfil de sabor final. Cada técnica es una elección deliberada que moldea la acidez, cuerpo y dulzura de la bebida.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <ProcessNode
                    icon="💧"
                    title="Beneficio Lavado"
                    description="La pulpa se retira antes del secado. Produce perfiles limpios y brillantes, acentuando la acidez y las notas más nítidas y delicadas del origen."
                />
                <ProcessNode
                    icon="🍯"
                    title="Beneficio Honey"
                    description="Se deja parte del mucílago (miel) en el grano durante el secado. Ofrece un equilibrio perfecto con dulzura acentuada y acidez moderada."
                />
                <ProcessNode
                    icon="☀️"
                    title="Beneficio Natural"
                    description="La cereza se seca entera. El grano absorbe los azúcares del fruto, resultando en sabores intensamente afrutados, cuerpo denso y baja acidez."
                />
            </div>
        </section>
    );
};

export default Processing;
