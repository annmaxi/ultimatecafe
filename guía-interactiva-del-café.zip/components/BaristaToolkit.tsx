
import React, { useState } from 'react';
import { BREWING_DATA, BrewingMethod } from '../constants';


const BaristaToolkit: React.FC = () => {
    const [activeMethod, setActiveMethod] = useState<BrewingMethod>('espresso');
    const activeData = BREWING_DATA[activeMethod];

    return (
        <section id="barista" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">La Caja de Herramientas del Barista</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    Cada método de preparación extrae un perfil de sabor diferente del mismo grano. Explora los parámetros básicos para algunos de los métodos más populares y descubre cómo influyen en la taza final.
                </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-8">
                {(Object.keys(BREWING_DATA) as BrewingMethod[]).map((method) => (
                    <button
                        key={method}
                        onClick={() => setActiveMethod(method)}
                        className={`px-4 py-2 rounded-full shadow font-semibold transition ${activeMethod === method ? 'bg-[#D3756B] text-white' : 'bg-white'}`}
                    >
                        {BREWING_DATA[method].title}
                    </button>
                ))}
            </div>
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto transition-all duration-500">
                {activeData && (
                    <div className="flex flex-col md:flex-row items-center gap-8">
                        <div className="text-6xl md:text-8xl">{activeData.icon}</div>
                        <div className="flex-1 text-center md:text-left">
                            <h4 className="text-2xl font-bold">{activeData.title}</h4>
                            <p className="text-gray-600 mt-2">{activeData.description}</p>
                            <div className="mt-6 flex flex-wrap justify-center md:justify-start gap-x-6 gap-y-4">
                                <div>
                                    <p className="text-sm text-gray-500">Molienda</p>
                                    <p className="font-bold text-lg">{activeData.grind}</p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Ratio Café:Agua</p>
                                    <p className="font-bold text-lg">{activeData.ratio}</p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Temperatura</p>
                                    <p className="font-bold text-lg">{activeData.temp}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </section>
    );
};

export default BaristaToolkit;
