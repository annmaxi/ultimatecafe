
import React from 'react';
import { Radar, RadarChart, PolarGrid, Legend, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { FLAVOR_PROFILES_DATA, COLORS } from '../constants';

const FlavorMap: React.FC = () => {
    return (
        <section id="sabor" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">El Mapa del Sabor Regional</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    El concepto de "terroir" significa que cada región productora imprime una firma sensorial única en sus granos. Este gráfico compara los perfiles de sabor característicos de cuatro orígenes emblemáticos.
                </p>
            </div>
            <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="w-full h-[400px] md:h-[500px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={FLAVOR_PROFILES_DATA}>
                            <PolarGrid />
                            <PolarAngleAxis dataKey="subject" tick={{ fill: COLORS.text }} />
                            <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fill: COLORS.text }} />
                            <Tooltip 
                                contentStyle={{
                                  backgroundColor: 'rgba(255, 255, 255, 0.8)',
                                  border: '1px solid #cccccc',
                                  borderRadius: '0.5rem',
                                }}
                            />
                            <Legend wrapperStyle={{ color: COLORS.text }} />
                            <Radar name="Etiopía (Lavado)" dataKey="A" stroke={COLORS.primary} fill={COLORS.primary} fillOpacity={0.2} />
                            <Radar name="Colombia (Lavado)" dataKey="B" stroke={COLORS.secondary} fill={COLORS.secondary} fillOpacity={0.2} />
                            <Radar name="Brasil (Natural)" dataKey="C" stroke={COLORS.accent} fill={COLORS.accent} fillOpacity={0.4} />
                            <Radar name="Kenia (Lavado)" dataKey="D" stroke={COLORS.kenya} fill={COLORS.kenya} fillOpacity={0.2} />
                        </RadarChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </section>
    );
};

export default FlavorMap;
