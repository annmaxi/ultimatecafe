
import React from 'react';

const Storytelling: React.FC = () => {
    return (
        <section id="storytelling" className="mb-12">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">Conectando con el Cliente: Storytelling y Venta</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    El barista moderno es un comunicador y prescriptor. Contar la historia del café, desde el productor hasta la taza, y personalizar la experiencia son claves para generar confianza y fidelidad.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white rounded-xl shadow-lg p-6">
                <div>
                    <h4 className="text-xl font-bold mb-3">El Barista como Comunicador</h4>
                    <p className="text-gray-600 mb-4">
                        Tu rol va más allá de preparar café; eres un embajador. Cada taza de café de especialidad es una narrativa de sostenibilidad, trazabilidad y excelencia. Al compartir la historia del origen, el cuidado del productor y las prácticas sostenibles, no solo justificas el precio, sino que creas una conexión emocional profunda con el cliente.
                    </p>
                    <h4 className="text-xl font-bold mb-3 mt-6">Personalización y Experiencia</h4>
                    <p className="text-gray-600">
                        Los consumidores buscan experiencias a medida. Ofrecer opciones de leche, endulzantes, intensidad y temperatura es fundamental. Las cafeterías independientes, al centrarse en la narración de historias y la construcción de comunidades, pueden ofrecer una autenticidad que las grandes cadenas no pueden replicar, fomentando la lealtad y la disposición a pagar un precio premium.
                    </p>
                </div>
                <div className="bg-[#D3756B] flex items-center justify-center text-white font-bold text-center rounded-lg h-64 md:h-96">
                    <img src="https://picsum.photos/seed/baristaclient/600/400" alt="Barista interactuando con cliente" className="w-full h-full object-cover rounded-md" />
                </div>
            </div>
        </section>
    );
};

export default Storytelling;
