
import React from 'react';

const Varieties: React.FC = () => {
    return (
        <section id="variedades" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">Las Estrellas del Cafeto: Variedades y Cultivo</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    Las dos variedades botánicas principales, Arábica y Robusta, definen gran parte del sabor del café. Su cultivo requiere condiciones específicas y prácticas sostenibles para asegurar la calidad.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white rounded-xl shadow-lg p-6">
                <div className="bg-[#E8A39C] flex items-center justify-center text-[#4E443F] font-bold text-center rounded-lg h-64 md:h-96 order-last md:order-first">
                    <img src="https://picsum.photos/seed/coffeefruit/600/400" alt="Plantas de café y cerezas" className="w-full h-full object-cover rounded-md" />
                </div>
                <div>
                    <h4 className="text-xl font-bold mb-3">Arábica vs. Robusta</h4>
                    <p className="text-gray-600 mb-4">
                        El <strong>Arábica</strong> es la base del café de especialidad, ofreciendo sabores suaves, dulces y complejos (chocolate, frutas, bayas). Se cultiva en altitudes elevadas para un desarrollo lento y concentración de azúcares. El <strong>Robusta</strong> tiene un sabor más fuerte, áspero y amargo, con más cafeína. Es valorado por su cuerpo y crema en espressos, y es más resistente a enfermedades.
                    </p>
                    <h4 className="text-xl font-bold mb-3 mt-6">Requerimientos de Cultivo</h4>
                    <p className="text-gray-600">
                        Las plantas de café Arábica son exigentes: prefieren luz brillante indirecta, riego equilibrado (suelo húmedo pero no encharcado), alta humedad y suelos ácidos, profundos y bien drenados. La poda y el abonado regular son esenciales. Las prácticas sostenibles son clave para la calidad y la viabilidad a largo plazo.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default Varieties;
