
import React from 'react';

const History: React.FC = () => {
    return (
        <section id="historia" className="mb-20">
            <div className="text-center mb-12">
                <h3 className="text-3xl font-bold">Un Viaje a los Orígenes: Historia y Terroir</h3>
                <p className="text-md text-gray-500 max-w-2xl mx-auto mt-2">
                    Descubre la fascinante historia del café, desde sus humildes comienzos en Etiopía hasta su expansión global, y cómo el "terroir" moldea su sabor único.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white rounded-xl shadow-lg p-6">
                <div>
                    <h4 className="text-xl font-bold mb-3">La Leyenda de Kaldi y la Expansión</h4>
                    <p className="text-gray-600 mb-4">
                        La historia del café se remonta al siglo X, con la leyenda del pastor etíope Kaldi, quien descubrió los efectos energizantes de las cerezas de café en sus cabras. Desde Etiopía, el café viajó a Yemen, donde los monjes sufíes lo adoptaron, y de ahí se extendió por el mundo islámico antes de llegar a Europa en el siglo XVII y, finalmente, a América.
                    </p>
                    <h4 className="text-xl font-bold mb-3 mt-6">El Concepto de Terroir</h4>
                    <p className="text-gray-600">
                        El "terroir" abarca las condiciones ambientales y prácticas agrícolas que influyen en el carácter del café. Factores como el clima (temperatura, humedad, lluvias), el tipo de suelo (volcánico, rico en minerales) y la altitud (que afecta la maduración lenta y la concentración de azúcares) son cruciales. Este concepto permite entender por qué cafés de la misma variedad, cultivados en diferentes lugares, ofrecen experiencias de sabor distintas.
                    </p>
                </div>
                <div className="bg-[#D3756B] flex items-center justify-center text-[#4E443F] font-bold text-center rounded-lg h-64 md:h-96">
                    <img src="https://picsum.photos/seed/coffeehistory/600/400" alt="Finca de café en Etiopía" className="w-full h-full object-cover rounded-md" />
                </div>
            </div>
        </section>
    );
};

export default History;
