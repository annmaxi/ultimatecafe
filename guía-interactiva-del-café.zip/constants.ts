
export const COLORS = {
    primary: '#D3756B',
    secondary: '#E8A39C',
    accent: '#F7D1BA',
    text: '#4E443F',
    bg: '#FDFBF8',
    kenya: '#A8D8B9',
};

export const TOP_PRODUCERS_DATA = [
    { name: 'Brasil', value: 2.68, fill: COLORS.primary },
    { name: 'Vietnam', value: 1.54, fill: COLORS.secondary },
    { name: 'Colombia', value: 0.754, fill: COLORS.accent },
    { name: 'Indonesia', value: 0.669, fill: COLORS.primary },
    { name: 'Honduras', value: 0.475, fill: COLORS.secondary },
    { name: 'Etiopía', value: 0.472, fill: COLORS.accent },
    { name: 'Perú', value: 0.346, fill: COLORS.primary },
    { name: 'India', value: 0.312, fill: COLORS.secondary },
    { name: 'Guatemala', value: 0.254, fill: COLORS.accent },
    { name: 'Uganda', value: 0.209, fill: COLORS.primary },
];

export const PRICE_FORECAST_DATA = [
    { name: 'Inicio 2025', 'Banco Mundial (Alcista)': 220, 'Reuters (Bajista)': 220 },
    { name: 'Med. 2025', 'Banco Mundial (Alcista)': 330, 'Reuters (Bajista)': 190 },
    { name: 'Fin 2025', 'Banco Mundial (Alcista)': 300, 'Reuters (Bajista)': 170 },
    { name: 'Med. 2026', 'Banco Mundial (Alcista)': 280, 'Reuters (Bajista)': 160 },
    { name: 'Fin 2026', 'Banco Mundial (Alcista)': 255, 'Reuters (Bajista)': 154 },
];

export const FLAVOR_PROFILES_DATA = [
    { subject: 'Acidez', A: 9, B: 7, C: 3, D: 10, fullMark: 10 },
    { subject: 'Cuerpo', A: 4, B: 7, C: 8, D: 7, fullMark: 10 },
    { subject: 'Dulzura', A: 7, B: 7, C: 8, D: 6, fullMark: 10 },
    { subject: 'Notas Florales', A: 9, B: 3, C: 1, D: 2, fullMark: 10 },
    { subject: 'Notas Frutales', A: 8, B: 6, C: 4, D: 9, fullMark: 10 },
    { subject: 'Chocolate/Nuez', A: 3, B: 8, C: 9, D: 2, fullMark: 10 },
];

export const BREWING_DATA = {
    espresso: {
        icon: '☕',
        title: 'Espresso',
        description: 'Un método de alta presión que resulta en una bebida corta, intensa y concentrada con una capa de crema característica. Es la base de muchas otras bebidas de café.',
        grind: 'Fina',
        ratio: '1:2 a 1:3',
        temp: '90-96°C'
    },
    v60: {
        icon: '💧',
        title: 'Hario V60',
        description: 'Un método de goteo (pour-over) que utiliza un filtro de papel cónico. Permite un gran control y produce una taza excepcionalmente limpia, clara y brillante, resaltando la acidez.',
        grind: 'Media',
        ratio: '1:16',
        temp: '96-98°C'
    },
    prensa: {
        icon: '⏳',
        title: 'Prensa Francesa',
        description: 'Un método de inmersión total. El café se infusiona directamente en el agua antes de ser separado por un émbolo. Produce una taza con cuerpo completo y textura rica.',
        grind: 'Gruesa',
        ratio: '1:16',
        temp: '92-96°C'
    },
    coldbrew: {
        icon: '🧊',
        title: 'Cold Brew',
        description: 'Infusión en frío durante 12-24 horas. El resultado es un concentrado suave, de baja acidez y dulzor natural, perfecto para tomar en frío solo o con hielo y leche.',
        grind: 'Gruesa',
        ratio: '1:10',
        temp: 'Fría'
    }
};

export type BrewingMethod = keyof typeof BREWING_DATA;
